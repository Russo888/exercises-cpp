#include <iostream>
#include <ctime>

#include <stdlib.h>
using namespace std;

int main()
{
srand((unsigned)time(NULL));
int a;
int b;
int c;
while((a!=b)&(a!=c)&(b!=c))
    {
      a= int d1=(rand()%6)+1;
      b= int d1=(rand()%6)+1;
      c= int d1=(rand()%6)+1;
      cout<<a;
      cout<<b;
      cout<<c;
    }
    return 0;
}
